# Welcome to the LexiTrain documentation!

## Get Started
To create a training plan, a period file must be created. This can be viewed at [period file](PeriodFile.md#period-file)

LexiTrain files can be created in plain text and saved as `.lt` file ([period](PeriodFile.md#period-file)) or `.slt` file ([session](SessionFile.md#session-file))

Period files can be written and compiled in the LexiTrain based web calender at [www.LexiTrain.com/calendar](/)

<br>
<h1 style="text-align: center;">Happy Training :)</h1> 