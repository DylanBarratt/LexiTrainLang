# Tokens
A token is a recognized string format in the LexiTrain code. 

## WORD
A WORD can be in two formats. <br> 
A single set of characters with no spaces. For example `HelloWorld!`
A set of characters surronded by `""` with spaces. For example `Hello World!`

## NUM
A NUM is a positive whole number. For example `99`