// Generated from /home/dylan/Coding/LexiTrainLang/ANTLR/SessionFile.g4 by ANTLR 4.13.1
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link SessionFileParser}.
 */
public interface SessionFileListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link SessionFileParser#file}.
	 * @param ctx the parse tree
	 */
	void enterFile(SessionFileParser.FileContext ctx);
	/**
	 * Exit a parse tree produced by {@link SessionFileParser#file}.
	 * @param ctx the parse tree
	 */
	void exitFile(SessionFileParser.FileContext ctx);
	/**
	 * Enter a parse tree produced by {@link SessionFileParser#metaData}.
	 * @param ctx the parse tree
	 */
	void enterMetaData(SessionFileParser.MetaDataContext ctx);
	/**
	 * Exit a parse tree produced by {@link SessionFileParser#metaData}.
	 * @param ctx the parse tree
	 */
	void exitMetaData(SessionFileParser.MetaDataContext ctx);
	/**
	 * Enter a parse tree produced by {@link SessionFileParser#section}.
	 * @param ctx the parse tree
	 */
	void enterSection(SessionFileParser.SectionContext ctx);
	/**
	 * Exit a parse tree produced by {@link SessionFileParser#section}.
	 * @param ctx the parse tree
	 */
	void exitSection(SessionFileParser.SectionContext ctx);
	/**
	 * Enter a parse tree produced by {@link SessionFileParser#workloads}.
	 * @param ctx the parse tree
	 */
	void enterWorkloads(SessionFileParser.WorkloadsContext ctx);
	/**
	 * Exit a parse tree produced by {@link SessionFileParser#workloads}.
	 * @param ctx the parse tree
	 */
	void exitWorkloads(SessionFileParser.WorkloadsContext ctx);
	/**
	 * Enter a parse tree produced by {@link SessionFileParser#workload}.
	 * @param ctx the parse tree
	 */
	void enterWorkload(SessionFileParser.WorkloadContext ctx);
	/**
	 * Exit a parse tree produced by {@link SessionFileParser#workload}.
	 * @param ctx the parse tree
	 */
	void exitWorkload(SessionFileParser.WorkloadContext ctx);
}