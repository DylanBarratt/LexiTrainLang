// Generated from ./PeriodFile.g4 by ANTLR 4.13.1
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link PeriodFileParser}.
 */
public interface PeriodFileListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link PeriodFileParser#file}.
	 * @param ctx the parse tree
	 */
	void enterFile(PeriodFileParser.FileContext ctx);
	/**
	 * Exit a parse tree produced by {@link PeriodFileParser#file}.
	 * @param ctx the parse tree
	 */
	void exitFile(PeriodFileParser.FileContext ctx);
	/**
	 * Enter a parse tree produced by {@link PeriodFileParser#metaDatas}.
	 * @param ctx the parse tree
	 */
	void enterMetaDatas(PeriodFileParser.MetaDatasContext ctx);
	/**
	 * Exit a parse tree produced by {@link PeriodFileParser#metaDatas}.
	 * @param ctx the parse tree
	 */
	void exitMetaDatas(PeriodFileParser.MetaDatasContext ctx);
	/**
	 * Enter a parse tree produced by {@link PeriodFileParser#metaData}.
	 * @param ctx the parse tree
	 */
	void enterMetaData(PeriodFileParser.MetaDataContext ctx);
	/**
	 * Exit a parse tree produced by {@link PeriodFileParser#metaData}.
	 * @param ctx the parse tree
	 */
	void exitMetaData(PeriodFileParser.MetaDataContext ctx);
	/**
	 * Enter a parse tree produced by {@link PeriodFileParser#sessionImport}.
	 * @param ctx the parse tree
	 */
	void enterSessionImport(PeriodFileParser.SessionImportContext ctx);
	/**
	 * Exit a parse tree produced by {@link PeriodFileParser#sessionImport}.
	 * @param ctx the parse tree
	 */
	void exitSessionImport(PeriodFileParser.SessionImportContext ctx);
	/**
	 * Enter a parse tree produced by {@link PeriodFileParser#periods}.
	 * @param ctx the parse tree
	 */
	void enterPeriods(PeriodFileParser.PeriodsContext ctx);
	/**
	 * Exit a parse tree produced by {@link PeriodFileParser#periods}.
	 * @param ctx the parse tree
	 */
	void exitPeriods(PeriodFileParser.PeriodsContext ctx);
	/**
	 * Enter a parse tree produced by {@link PeriodFileParser#period}.
	 * @param ctx the parse tree
	 */
	void enterPeriod(PeriodFileParser.PeriodContext ctx);
	/**
	 * Exit a parse tree produced by {@link PeriodFileParser#period}.
	 * @param ctx the parse tree
	 */
	void exitPeriod(PeriodFileParser.PeriodContext ctx);
	/**
	 * Enter a parse tree produced by {@link PeriodFileParser#day}.
	 * @param ctx the parse tree
	 */
	void enterDay(PeriodFileParser.DayContext ctx);
	/**
	 * Exit a parse tree produced by {@link PeriodFileParser#day}.
	 * @param ctx the parse tree
	 */
	void exitDay(PeriodFileParser.DayContext ctx);
	/**
	 * Enter a parse tree produced by {@link PeriodFileParser#dayLoop}.
	 * @param ctx the parse tree
	 */
	void enterDayLoop(PeriodFileParser.DayLoopContext ctx);
	/**
	 * Exit a parse tree produced by {@link PeriodFileParser#dayLoop}.
	 * @param ctx the parse tree
	 */
	void exitDayLoop(PeriodFileParser.DayLoopContext ctx);
	/**
	 * Enter a parse tree produced by {@link PeriodFileParser#dayData}.
	 * @param ctx the parse tree
	 */
	void enterDayData(PeriodFileParser.DayDataContext ctx);
	/**
	 * Exit a parse tree produced by {@link PeriodFileParser#dayData}.
	 * @param ctx the parse tree
	 */
	void exitDayData(PeriodFileParser.DayDataContext ctx);
	/**
	 * Enter a parse tree produced by {@link PeriodFileParser#dayNotes}.
	 * @param ctx the parse tree
	 */
	void enterDayNotes(PeriodFileParser.DayNotesContext ctx);
	/**
	 * Exit a parse tree produced by {@link PeriodFileParser#dayNotes}.
	 * @param ctx the parse tree
	 */
	void exitDayNotes(PeriodFileParser.DayNotesContext ctx);
	/**
	 * Enter a parse tree produced by {@link PeriodFileParser#workout}.
	 * @param ctx the parse tree
	 */
	void enterWorkout(PeriodFileParser.WorkoutContext ctx);
	/**
	 * Exit a parse tree produced by {@link PeriodFileParser#workout}.
	 * @param ctx the parse tree
	 */
	void exitWorkout(PeriodFileParser.WorkoutContext ctx);
	/**
	 * Enter a parse tree produced by {@link PeriodFileParser#imported}.
	 * @param ctx the parse tree
	 */
	void enterImported(PeriodFileParser.ImportedContext ctx);
	/**
	 * Exit a parse tree produced by {@link PeriodFileParser#imported}.
	 * @param ctx the parse tree
	 */
	void exitImported(PeriodFileParser.ImportedContext ctx);
	/**
	 * Enter a parse tree produced by {@link PeriodFileParser#session}.
	 * @param ctx the parse tree
	 */
	void enterSession(PeriodFileParser.SessionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PeriodFileParser#session}.
	 * @param ctx the parse tree
	 */
	void exitSession(PeriodFileParser.SessionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PeriodFileParser#sessionSection}.
	 * @param ctx the parse tree
	 */
	void enterSessionSection(PeriodFileParser.SessionSectionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PeriodFileParser#sessionSection}.
	 * @param ctx the parse tree
	 */
	void exitSessionSection(PeriodFileParser.SessionSectionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PeriodFileParser#workloads}.
	 * @param ctx the parse tree
	 */
	void enterWorkloads(PeriodFileParser.WorkloadsContext ctx);
	/**
	 * Exit a parse tree produced by {@link PeriodFileParser#workloads}.
	 * @param ctx the parse tree
	 */
	void exitWorkloads(PeriodFileParser.WorkloadsContext ctx);
	/**
	 * Enter a parse tree produced by {@link PeriodFileParser#workloadL}.
	 * @param ctx the parse tree
	 */
	void enterWorkloadL(PeriodFileParser.WorkloadLContext ctx);
	/**
	 * Exit a parse tree produced by {@link PeriodFileParser#workloadL}.
	 * @param ctx the parse tree
	 */
	void exitWorkloadL(PeriodFileParser.WorkloadLContext ctx);
	/**
	 * Enter a parse tree produced by {@link PeriodFileParser#workload}.
	 * @param ctx the parse tree
	 */
	void enterWorkload(PeriodFileParser.WorkloadContext ctx);
	/**
	 * Exit a parse tree produced by {@link PeriodFileParser#workload}.
	 * @param ctx the parse tree
	 */
	void exitWorkload(PeriodFileParser.WorkloadContext ctx);
	/**
	 * Enter a parse tree produced by {@link PeriodFileParser#lt}.
	 * @param ctx the parse tree
	 */
	void enterLt(PeriodFileParser.LtContext ctx);
	/**
	 * Exit a parse tree produced by {@link PeriodFileParser#lt}.
	 * @param ctx the parse tree
	 */
	void exitLt(PeriodFileParser.LtContext ctx);
	/**
	 * Enter a parse tree produced by {@link PeriodFileParser#gt}.
	 * @param ctx the parse tree
	 */
	void enterGt(PeriodFileParser.GtContext ctx);
	/**
	 * Exit a parse tree produced by {@link PeriodFileParser#gt}.
	 * @param ctx the parse tree
	 */
	void exitGt(PeriodFileParser.GtContext ctx);
	/**
	 * Enter a parse tree produced by {@link PeriodFileParser#between}.
	 * @param ctx the parse tree
	 */
	void enterBetween(PeriodFileParser.BetweenContext ctx);
	/**
	 * Exit a parse tree produced by {@link PeriodFileParser#between}.
	 * @param ctx the parse tree
	 */
	void exitBetween(PeriodFileParser.BetweenContext ctx);
}