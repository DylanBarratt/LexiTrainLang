// Generated from ./Imports.g4 by ANTLR 4.13.1
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link ImportsParser}.
 */
public interface ImportsListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link ImportsParser#file}.
	 * @param ctx the parse tree
	 */
	void enterFile(ImportsParser.FileContext ctx);
	/**
	 * Exit a parse tree produced by {@link ImportsParser#file}.
	 * @param ctx the parse tree
	 */
	void exitFile(ImportsParser.FileContext ctx);
	/**
	 * Enter a parse tree produced by {@link ImportsParser#importStatement}.
	 * @param ctx the parse tree
	 */
	void enterImportStatement(ImportsParser.ImportStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link ImportsParser#importStatement}.
	 * @param ctx the parse tree
	 */
	void exitImportStatement(ImportsParser.ImportStatementContext ctx);
}