// Generated from ./PeriodFile.g4 by ANTLR 4.13.1
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link PeriodFileParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface PeriodFileVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link PeriodFileParser#file}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFile(PeriodFileParser.FileContext ctx);
	/**
	 * Visit a parse tree produced by {@link PeriodFileParser#metaDatas}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMetaDatas(PeriodFileParser.MetaDatasContext ctx);
	/**
	 * Visit a parse tree produced by {@link PeriodFileParser#metaData}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMetaData(PeriodFileParser.MetaDataContext ctx);
	/**
	 * Visit a parse tree produced by {@link PeriodFileParser#sessionImport}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSessionImport(PeriodFileParser.SessionImportContext ctx);
	/**
	 * Visit a parse tree produced by {@link PeriodFileParser#periods}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPeriods(PeriodFileParser.PeriodsContext ctx);
	/**
	 * Visit a parse tree produced by {@link PeriodFileParser#period}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPeriod(PeriodFileParser.PeriodContext ctx);
	/**
	 * Visit a parse tree produced by {@link PeriodFileParser#day}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDay(PeriodFileParser.DayContext ctx);
	/**
	 * Visit a parse tree produced by {@link PeriodFileParser#dayLoop}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDayLoop(PeriodFileParser.DayLoopContext ctx);
	/**
	 * Visit a parse tree produced by {@link PeriodFileParser#dayData}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDayData(PeriodFileParser.DayDataContext ctx);
	/**
	 * Visit a parse tree produced by {@link PeriodFileParser#dayNotes}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDayNotes(PeriodFileParser.DayNotesContext ctx);
	/**
	 * Visit a parse tree produced by {@link PeriodFileParser#workout}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWorkout(PeriodFileParser.WorkoutContext ctx);
	/**
	 * Visit a parse tree produced by {@link PeriodFileParser#imported}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitImported(PeriodFileParser.ImportedContext ctx);
	/**
	 * Visit a parse tree produced by {@link PeriodFileParser#session}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSession(PeriodFileParser.SessionContext ctx);
	/**
	 * Visit a parse tree produced by {@link PeriodFileParser#sessionSection}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSessionSection(PeriodFileParser.SessionSectionContext ctx);
	/**
	 * Visit a parse tree produced by {@link PeriodFileParser#workloads}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWorkloads(PeriodFileParser.WorkloadsContext ctx);
	/**
	 * Visit a parse tree produced by {@link PeriodFileParser#workloadL}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWorkloadL(PeriodFileParser.WorkloadLContext ctx);
	/**
	 * Visit a parse tree produced by {@link PeriodFileParser#workload}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWorkload(PeriodFileParser.WorkloadContext ctx);
	/**
	 * Visit a parse tree produced by {@link PeriodFileParser#lt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLt(PeriodFileParser.LtContext ctx);
	/**
	 * Visit a parse tree produced by {@link PeriodFileParser#gt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGt(PeriodFileParser.GtContext ctx);
	/**
	 * Visit a parse tree produced by {@link PeriodFileParser#between}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBetween(PeriodFileParser.BetweenContext ctx);
}