// Generated from ./SessionFile.g4 by ANTLR 4.13.1
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link SessionFileParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface SessionFileVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link SessionFileParser#file}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFile(SessionFileParser.FileContext ctx);
	/**
	 * Visit a parse tree produced by {@link SessionFileParser#metaDatas}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMetaDatas(SessionFileParser.MetaDatasContext ctx);
	/**
	 * Visit a parse tree produced by {@link SessionFileParser#metaData}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMetaData(SessionFileParser.MetaDataContext ctx);
	/**
	 * Visit a parse tree produced by {@link SessionFileParser#section}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSection(SessionFileParser.SectionContext ctx);
	/**
	 * Visit a parse tree produced by {@link SessionFileParser#sectionContents}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSectionContents(SessionFileParser.SectionContentsContext ctx);
	/**
	 * Visit a parse tree produced by {@link SessionFileParser#structure}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStructure(SessionFileParser.StructureContext ctx);
	/**
	 * Visit a parse tree produced by {@link SessionFileParser#workloads}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWorkloads(SessionFileParser.WorkloadsContext ctx);
	/**
	 * Visit a parse tree produced by {@link SessionFileParser#note}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNote(SessionFileParser.NoteContext ctx);
	/**
	 * Visit a parse tree produced by {@link SessionFileParser#workload}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWorkload(SessionFileParser.WorkloadContext ctx);
	/**
	 * Visit a parse tree produced by {@link SessionFileParser#lt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLt(SessionFileParser.LtContext ctx);
	/**
	 * Visit a parse tree produced by {@link SessionFileParser#gt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGt(SessionFileParser.GtContext ctx);
	/**
	 * Visit a parse tree produced by {@link SessionFileParser#between}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBetween(SessionFileParser.BetweenContext ctx);
}