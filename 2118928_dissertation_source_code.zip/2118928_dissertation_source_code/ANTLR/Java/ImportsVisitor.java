// Generated from ./Imports.g4 by ANTLR 4.13.1
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link ImportsParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface ImportsVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link ImportsParser#file}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFile(ImportsParser.FileContext ctx);
	/**
	 * Visit a parse tree produced by {@link ImportsParser#importStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitImportStatement(ImportsParser.ImportStatementContext ctx);
}